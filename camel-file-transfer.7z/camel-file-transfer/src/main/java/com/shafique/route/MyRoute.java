package com.shafique.route;

import org.apache.camel.builder.RouteBuilder;

public class MyRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		from("file:D:\\camelproject\\source?noop=true").to("file:D:\\camelproject\\destination");
	}

	
}
