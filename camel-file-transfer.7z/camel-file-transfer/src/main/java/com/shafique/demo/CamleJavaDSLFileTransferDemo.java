package com.shafique.demo;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;

import com.shafique.route.MyRoute;

public class CamleJavaDSLFileTransferDemo {

	public static void main(String[] args) {
		MyRoute mr = new MyRoute();
		CamelContext ctx = new DefaultCamelContext();
		
		try {
			ctx.addRoutes(mr);
			ctx.start();
			Thread.sleep(3000);
			ctx.stop();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
