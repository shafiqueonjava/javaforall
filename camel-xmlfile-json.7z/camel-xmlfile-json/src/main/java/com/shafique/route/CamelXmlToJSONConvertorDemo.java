package com.shafique.route;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelXmlToJSONConvertorDemo {

	public static void main(String[] args) {
		RouteBuilder mr = new MyRoute();
		CamelContext ctx = new DefaultCamelContext();
		
		try {
			ctx.addRoutes(mr);
			ctx.start();
			Thread.sleep(2000);
			ctx.stop();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
