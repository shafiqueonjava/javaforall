package com.shafique.route;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class MyProcessor implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		String output = exchange.getIn().getBody(String.class);
		System.out.println(output);
		exchange.getOut().setBody(output);
		

	}

}
